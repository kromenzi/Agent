import { Router } from 'express';
import { authenticate, requireRole, auditLog, type AuthRequest } from '../auth/middleware.js';
import { importFromGitHub, importFromZip } from './importer.js';
import { detectStack } from './detector.js';
import { runInContainer } from '../runner/docker.service.js';
import db from '../../config/database.js';
import { logger } from '../../shared/logger.js';
import multer from 'multer';

const router = Router();
const upload = multer({ limits: { fileSize: 50 * 1024 * 1024 } }); // 50MB limit

// Import from GitHub
router.post(
  '/import/github',
  authenticate,
  requireRole('admin', 'dev'),
  auditLog('import_github', 'project'),
  async (req: AuthRequest, res) => {
    try {
      const { url } = req.body;
      if (!url?.includes('github.com')) {
        return res.status(400).json({ error: 'Invalid GitHub URL' });
      }

      const projectId = await importFromGitHub(url, req.user!.id);
      res.json({ success: true, projectId, message: 'Import started' });
    } catch (error) {
      logger.error('GitHub import failed:', error);
      res.status(500).json({ error: 'Import failed', details: (error as Error).message });
    }
  }
);

// Import from ZIP
router.post(
  '/import/zip',
  authenticate,
  requireRole('admin', 'dev'),
  upload.single('file'),
  auditLog('import_zip', 'project'),
  async (req: AuthRequest, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: 'No file uploaded' });
      }

      const projectId = await importFromZip(req.file.buffer, req.file.originalname, req.user!.id);
      res.json({ success: true, projectId });
    } catch (error) {
      logger.error('ZIP import failed:', error);
      res.status(500).json({ error: 'Import failed' });
    }
  }
);

// List projects
router.get('/', authenticate, (req: AuthRequest, res) => {
  const projects = db.prepare(`
    SELECT p.*, u.email as creator_email 
    FROM projects p 
    LEFT JOIN users u ON p.created_by = u.id
    WHERE p.created_by = ? OR ? = 'admin'
    ORDER BY p.created_at DESC
  `).all(req.user!.id, req.user!.role);
  
  res.json(projects);
});

// Get project details
router.get('/:id', authenticate, (req: AuthRequest, res) => {
  const project = db.prepare('SELECT * FROM projects WHERE id = ?').get(req.params.id);
  if (!project) return res.status(404).json({ error: 'Project not found' });
  
  const files = db.prepare('SELECT path, size_bytes FROM project_files WHERE project_id = ?')
    .all(req.params.id);
  
  res.json({ ...project, files });
});

// Run command
router.post(
  '/:id/run',
  authenticate,
  requireRole('admin', 'dev'),
  auditLog('execute', 'execution', 'warning'),
  async (req: AuthRequest, res) => {
    const { command, env } = req.body;
    const project = db.prepare('SELECT * FROM projects WHERE id = ?').get(req.params.id);
    
    if (!project) return res.status(404).json({ error: 'Project not found' });

    const executionId = crypto.randomUUID();
    
    // Save execution record
    db.prepare(`
      INSERT INTO executions (id, project_id, type, command, status, created_by)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(executionId, req.params.id, 'run', command, 'pending', req.user!.id);

    // Run async
    runInContainer(project.local_path, command, env)
      .then(result => {
        db.prepare(`
          UPDATE executions 
          SET status = ?, exit_code = ?, logs = ?, completed_at = CURRENT_TIMESTAMP 
          WHERE id = ?
        `).run(
          result.exitCode === 0 ? 'success' : 'failed',
          result.exitCode,
          JSON.stringify(result.logs),
          executionId
        );
      })
      .catch(error => {
        db.prepare('UPDATE executions SET status = ?, logs = ? WHERE id = ?')
          .run('failed', JSON.stringify([{ message: error.message }]), executionId);
      });

    res.json({ executionId, status: 'started' });
  }
);

// Get execution logs
router.get('/:id/executions/:executionId', authenticate, (req: AuthRequest, res) => {
  const execution = db.prepare(`
    SELECT e.*, p.name as project_name 
    FROM executions e 
    JOIN projects p ON e.project_id = p.id 
    WHERE e.id = ? AND e.project_id = ?
  `).get(req.params.executionId, req.params.id);
  
  if (!execution) return res.status(404).json({ error: 'Execution not found' });
  
  res.json({
    ...execution,
    logs: JSON.parse(execution.logs || '[]')
  });
});

export default router;