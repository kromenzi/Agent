import { promises as fs, existsSync, mkdirSync } from 'fs';
import { join } from 'path';
import simpleGit from 'simple-git';
import AdmZip from 'adm-zip';
import { v4 as uuidv4 } from 'uuid';
import db from '../../config/database.js';
import { detectStack, analyzeProjectStructure } from './detector.js';
import { logger } from '../../shared/logger.js';

const PROJECTS_BASE = process.env.PROJECTS_BASE_PATH || './data/projects';

export async function importFromGitHub(url: string, userId: string): Promise<string> {
  const projectId = uuidv4();
  const projectPath = join(PROJECTS_BASE, projectId);
  
  try {
    mkdirSync(projectPath, { recursive: true });
    
    logger.info(`Cloning ${url} to ${projectPath}`);
    await simpleGit().clone(url, projectPath, ['--depth', '1']);
    
    // Clean .git to save space
    await fs.rm(join(projectPath, '.git'), { recursive: true, force: true });
    
    const stack = detectStack(projectPath);
    const structure = analyzeProjectStructure(projectPath);
    
    const projectName = url.split('/').pop()?.replace('.git', '') || 'unknown';
    
    db.prepare(`
      INSERT INTO projects (
        id, name, source_type, source_url, local_path, 
        stack_detected, stack_confidence, install_command, run_command, build_command,
        env_keys_required, status, created_by
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      projectId,
      projectName,
      'github',
      url,
      projectPath,
      stack?.name || 'unknown',
      stack?.confidence || 0,
      stack?.installCmd || null,
      stack?.runCmd || null,
      stack?.buildCmd || null,
      JSON.stringify(stack?.envKeys || []),
      stack ? 'ready' : 'analyzing',
      userId
    );

    // Scan