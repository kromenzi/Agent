import { readFileSync, existsSync, readdirSync } from 'fs';
import { join } from 'path';
import type { StackInfo } from '../../shared/types.js';

const STACK_PATTERNS = [
  {
    name: 'Next.js',
    files: ['next.config.js', 'next.config.mjs', 'next.config.ts'],
    check: (dir: string) => existsSync(join(dir, 'package.json')) && 
      JSON.parse(readFileSync(join(dir, 'package.json'), 'utf-8')).dependencies?.next,
    installCmd: 'npm install',
    runCmd: 'npm run dev',
    buildCmd: 'npm run build',
    envKeys: ['NEXT_PUBLIC_', 'DATABASE_URL', 'OPENAI_API_KEY']
  },
  {
    name: 'React (Vite)',
    files: ['vite.config.js', 'vite.config.ts'],
    check: (dir: string) => existsSync(join(dir, 'vite.config.js')) || existsSync(join(dir, 'vite.config.ts')),
    installCmd: 'npm install',
    runCmd: 'npm run dev',
    buildCmd: 'npm run build',
    envKeys: ['VITE_', 'API_URL']
  },
  {
    name: 'Node.js (Express)',
    files: ['package.json'],
    check: (dir: string) => {
      if (!existsSync(join(dir, 'package.json'))) return false;
      const pkg = JSON.parse(readFileSync(join(dir, 'package.json'), 'utf-8'));
      return pkg.dependencies?.express && !pkg.dependencies?.next;
    },
    installCmd: 'npm install',
    runCmd: 'npm start',
    buildCmd: 'npm run build',
    envKeys: ['PORT', 'NODE_ENV', 'DATABASE_URL']
  },
  {
    name: 'Python (FastAPI)',
    files: ['requirements.txt', 'pyproject.toml'],
    check: (dir: string) => existsSync(join(dir, 'requirements.txt')) || existsSync(join(dir, 'pyproject.toml')),
    installCmd: 'pip install -r requirements.txt',
    runCmd: 'uvicorn main:app --reload --host 0.0.0.0 --port 8000',
    buildCmd: null,
    envKeys: ['DATABASE_URL', 'SECRET_KEY']
  },
  {
    name: 'Python (Django)',
    files: ['manage.py', 'requirements.txt'],
    check: (dir: string) => existsSync(join(dir, 'manage.py')),
    installCmd: 'pip install -r requirements.txt',
    runCmd: 'python manage.py runserver 0.0.0.0:8000',
    buildCmd: 'python manage.py migrate',
    envKeys: ['DJANGO_SECRET_KEY', 'DEBUG', 'DATABASE_URL']
  },
  {
    name: 'Java (Maven)',
    files: ['pom.xml'],
    check: (dir: string) => existsSync(join(dir, 'pom.xml')),
    installCmd: 'mvn install',
    runCmd: 'mvn spring-boot:run',
    buildCmd: 'mvn package',
    envKeys: ['SPRING_PROFILES_ACTIVE', 'DATABASE_URL']
  },
  {
    name: '.NET Core',
    files: ['*.csproj'],
    check: (dir: string) => readdirSync(dir).some(f => f.endsWith('.csproj')),
    installCmd: 'dotnet restore',
    runCmd: 'dotnet run',
    buildCmd: 'dotnet build',
    envKeys: ['ASPNETCORE_ENVIRONMENT', 'CONNECTION_STRING']
  }
];

export function detectStack(projectPath: string): StackInfo | null {
  const detectedFiles: string[] = [];
  let bestMatch: StackInfo | null = null;
  let highestConfidence = 0;

  for (const stack of STACK_PATTERNS) {
    let confidence = 0;
    let foundFiles: string[] = [];

    // Check for specific files
    for (const file of stack.files) {
      if (file.includes('*')) {
        const pattern = file.replace('*', '');
        const matches = readdirSync(projectPath).filter(f => f.endsWith(pattern));
        if (matches.length > 0) {
          confidence += 20;
          foundFiles.push(...matches);
        }
      } else if (existsSync(join(projectPath, file))) {
        confidence += 30;
        foundFiles.push(file);
      }
    }

    // Run custom check
    if (stack.check(projectPath)) {
      confidence += 50;
    }

    // Check for lock files (additional confidence)
    if (existsSync(join(projectPath, 'package-lock.json'))) confidence += 10;
    if (existsSync(join(projectPath, 'yarn.lock'))) confidence += 10;
    if (existsSync(join(projectPath, 'pnpm-lock.yaml'))) confidence += 10;

    if (confidence > highestConfidence && confidence >= 40) {
      highestConfidence = confidence;
      bestMatch = {
        name: stack.name,
        confidence: Math.min(confidence, 100),
        installCmd: stack.installCmd,
        runCmd: stack.runCmd,
        buildCmd: stack.buildCmd || undefined,
        envKeys: stack.envKeys,
        files: foundFiles
      };
    }
  }

  return bestMatch;
}

export function analyzeProjectStructure(projectPath: string) {
  const structure = {
    hasGit: existsSync(join(projectPath, '.git')),
    hasDocker: existsSync(join(projectPath, 'Dockerfile')),
    hasDockerCompose: existsSync(join(projectPath, 'docker-compose.yml')),
    hasReadme: existsSync(join(projectPath, 'README.md')),
    hasTests: existsSync(join(projectPath, '__tests__')) || existsSync(join(projectPath, 'tests')),
    hasCI: existsSync(join(projectPath, '.github')),
    envExample: existsSync(join(projectPath, '.env.example')) ? readFileSync(join(projectPath, '.env.example'), 'utf-8') : null
  };

  return structure;
}