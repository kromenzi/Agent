import OpenAI from 'openai';
import { readFileSync } from 'fs';
import { join } from 'path';
import db from '../../config/database.js';
import { logger } from '../../shared/logger.js';
import type { AIPlan } from '../../shared/types.js';

const openai = process.env.OPENAI_API_KEY ? new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
}) : null;

export async function analyzeProject(projectId: string): Promise<string> {
  if (!openai) throw new Error('OpenAI not configured');

  const project = db.prepare('SELECT * FROM projects WHERE id = ?').get(projectId);
  if (!project) throw new Error('Project not found');

  // Get key files
  const files = db.prepare(`
    SELECT path FROM project_files 
    WHERE project_id = ? AND path IN ('package.json', 'README.md', 'requirements.txt', 'src/index.ts', 'src/main.py')
    LIMIT 5
  `).all(projectId);

  const fileContents = files.map((f: any) => {
    try {
      const content = readFileSync(join(project.local_path, f.path), 'utf-8');
      return `File: ${f.path}\n\`\`\`\n${content.substring(0, 2000)}\n\`\`\``;
    } catch {
      return '';
    }
  }).join('\n\n');

  const prompt = `
Analyze this ${project.stack_detected} project and identify potential improvements or issues.

Project Structure:
${fileContents}

Provide:
1. Quick summary of the project
2. Any obvious issues (missing deps, config problems)
3. One simple fix suggestion (lint, format, or small refactor)
4. Test coverage status
`;

  const response = await openai.chat.completions.create({
    model: 'gpt-4-turbo-preview',
    messages: [{ role: 'user', content: prompt }],
    temperature: 0.3
  });

  return response.choices[0].message.content || 'No analysis available';
}

export async function generateFixPlan(projectId: string, issue: string): Promise<AIPlan> {
  if (!openai) throw new Error('OpenAI not configured');

  const project = db.prepare('SELECT * FROM projects WHERE id = ?').get(projectId);
  
  // Get relevant files based on issue
  const files = db.prepare(`
    SELECT path FROM project_files 
    WHERE project_id = ? AND path LIKE '%.js' OR path LIKE '%.ts' OR path LIKE '%.py'
    LIMIT 10
  `).all(projectId);

  const prompt = `
Project: ${project.name} (${project.stack_detected})

User Request: ${issue}

Available Files:
${files.map((f: any) => `- ${f.path}`).join('\n')}

Create a plan:
1. Which files need changes?
2. What specific changes?
3. Safety assessment (low/medium/high risk)

Format as JSON:
{
  "affected_files": ["path1", "path2"],
  "plan_steps": ["step 1", "step 2"],
  "risk_level": "low",
  "explanation": "why this is safe"
}
`;

  const response = await openai.chat.completions.create({
    model: 'gpt-4-turbo-preview',
    messages: [{ role: 'user', content: prompt }],
    response_format: { type: 'json_object' },
    temperature: 0.2
  });

  const planData = JSON.parse(response.choices[0].message.content || '{}');
  
  const planId = crypto.randomUUID();
  
  db.prepare(`
    INSERT INTO ai_plans (id, project_id, user_prompt, plan_text, affected_files, status, created_by)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(
    planId,
    projectId,
    issue,
    JSON.stringify(planData.plan_steps, null, 2),
    JSON.stringify(planData.affected_files),
    'draft',
    project.created_by
  );

  return {
    id: planId,
    project_id: projectId,
    user_prompt: issue,
    plan_text: planData.plan_steps.join('\n'),
    affected_files: planData.affected_files,
    status: 'draft'
  };
}

export async function executePlan(planId: string, autoApply: boolean = false): Promise<void> {
  const plan = db.prepare('SELECT * FROM ai_plans WHERE id = ?').get(planId);
  if (!plan || plan.status !== 'draft') throw new Error('Invalid plan status');

  if (!autoApply) {
    // Require manual approval
    db.prepare('UPDATE ai_plans SET status = ? WHERE id = ?').run('pending_approval', planId);
    return;
  }

  // Execute the plan (simplified - would generate actual diffs)
  logger.info(`Executing plan ${planId}`);
  
  db.prepare('UPDATE ai_plans SET status = ?, applied_at = CURRENT_TIMESTAMP WHERE id = ?')
    .run('applied', planId);
}