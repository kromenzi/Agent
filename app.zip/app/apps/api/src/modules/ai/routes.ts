import { Router } from 'express';
import { authenticate, requireRole, type AuthRequest } from '../auth/middleware.js';
import { analyzeProject, generateFixPlan } from './agent.service.js';
import db from '../../config/database.js';

const router = Router();

// Analyze project
router.post('/:projectId/analyze', authenticate, async (req: AuthRequest, res) => {
  try {
    const analysis = await analyzeProject(req.params.projectId);
    res.json({ analysis });
  } catch (error) {
    res.status(500).json({ error: (error as Error).message });
  }
});

// Generate fix plan
router.post('/:projectId/plan', authenticate, requireRole('admin', 'dev'), async (req: AuthRequest, res) => {
  try {
    const { issue } = req.body;
    const plan = await generateFixPlan(req.params.projectId, issue);
    res.json(plan);
  } catch (error) {
    res.status(500).json({ error: (error as Error).message });
  }
});

// Get plans
router.get('/:projectId/plans', authenticate, (req: AuthRequest, res) => {
  const plans = db.prepare('SELECT * FROM ai_plans WHERE project_id = ? ORDER BY created_at DESC')
    .all(req.params.projectId);
  res.json(plans);
});

export default router;