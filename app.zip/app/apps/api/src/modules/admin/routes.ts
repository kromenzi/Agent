import { Router } from 'express';
import { authenticate, requireRole, type AuthRequest } from '../auth/middleware.js';
import db from '../../config/database.js';

const router = Router();

// Get all users (admin only)
router.get('/users', authenticate, requireRole('admin'), (req: AuthRequest, res) => {
  const users = db.prepare('SELECT id, email, role, created_at FROM users').all();
  res.json(users);
});

// Get audit logs (admin only)
router.get('/logs', authenticate, requireRole('admin'), (req: AuthRequest, res) => {
  const { limit = 100, offset = 0 } = req.query;
  
  const logs = db.prepare(`
    SELECT a.*, u.email as user_email 
    FROM audit_logs a 
    LEFT JOIN users u ON a.user_id = u.id 
    ORDER BY a.created_at DESC 
    LIMIT ? OFFSET ?
  `).all(limit, offset);
  
  res.json(logs);
});

// Get system stats
router.get('/stats', authenticate, requireRole('admin'), (req: AuthRequest, res) => {
  const stats = {
    totalProjects: db.prepare('SELECT COUNT(*) as count FROM projects').get().count,
    totalUsers: db.prepare('SELECT COUNT(*) as count FROM users').get().count,
    totalExecutions: db.prepare('SELECT COUNT(*) as count FROM executions').get().count,
    recentExecutions: db.prepare(`
      SELECT status, COUNT(*) as count 
      FROM executions 
      WHERE created_at > datetime('now', '-7 days')
      GROUP BY status
    `).all()
  };
  
  res.json(stats);
});

export default router;