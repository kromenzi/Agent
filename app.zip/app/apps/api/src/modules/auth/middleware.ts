import jwt from 'jsonwebtoken';
import { Request, Response, NextFunction } from 'express';
import { env } from '../../config/env.js';
import db from '../../config/database.js';
import { logger } from '../../shared/logger.js';

export interface AuthRequest extends Request {
  user?: {
    id: string;
    email: string;
    role: 'admin' | 'dev' | 'viewer';
  };
}

export function authenticate(req: AuthRequest, res: Response, next: NextFunction) {
  const token = req.headers.authorization?.replace('Bearer ', '');
  
  if (!token) {
    return res.status(401).json({ error: 'No token provided' });
  }

  try {
    const decoded = jwt.verify(token, env.JWT_SECRET) as any;
    req.user = decoded;
    next();
  } catch {
    return res.status(401).json({ error: 'Invalid token' });
  }
}

export function requireRole(...roles: string[]) {
  return (req: AuthRequest, res: Response, next: NextFunction) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({ error: 'Insufficient permissions' });
    }
    next();
  };
}

export function auditLog(action: string, entityType: string, severity: 'info' | 'warning' | 'critical' = 'info') {
  return (req: AuthRequest, res: Response, next: NextFunction) => {
    const originalSend = res.send;
    
    res.send = function(body) {
      // Log after response
      if (req.user) {
        db.prepare(`
          INSERT INTO audit_logs (user_id, action, entity_type, entity_id, severity, ip_address, user_agent, details)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `).run(
          req.user.id,
          action,
          entityType,
          req.params.id || 'unknown',
          severity,
          req.ip,
          req.headers['user-agent'],
          JSON.stringify({ method: req.method, path: req.path, statusCode: res.statusCode })
        );
      }
      
      return originalSend.call(this, body);
    };
    
    next();
  };
}