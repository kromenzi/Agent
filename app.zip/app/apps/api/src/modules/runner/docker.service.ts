import Docker from 'dockerode';
import { join } from 'path';
import { logger } from '../../shared/logger.js';
import type { LogEntry } from '../../shared/types.js';

const docker = new Docker();
const NETWORK_NAME = process.env.DOCKER_NETWORK || 'ai-coding-network';

// Ensure network exists
async function ensureNetwork() {
  try {
    await docker.getNetwork(NETWORK_NAME).inspect();
  } catch {
    await docker.createNetwork({
      Name: NETWORK_NAME,
      Driver: 'bridge',
      Internal: false
    });
    logger.info(`Created network: ${NETWORK_NAME}`);
  }
}

export interface ExecutionResult {
  exitCode: number;
  logs: LogEntry[];
  duration: number;
}

export async function runInContainer(
  projectPath: string,
  command: string,
  envVars: Record<string, string> = {},
  timeoutMs: number = 300000
): Promise<ExecutionResult> {
  await ensureNetwork();
  
  const logs: LogEntry[] = [];
  const startTime = Date.now();
  
  const container = await docker.createContainer({
    Image: 'ai-coding-runner:latest',
    Cmd: ['sh', '-c', command],
    WorkingDir: '/workspace',
    HostConfig: {
      Binds: [`${projectPath}:/workspace:rw`],
      NetworkMode: NETWORK_NAME,
      Memory: 2 * 1024 * 1024 * 1024, // 2GB limit
      CpuQuota: 100000, // 1 CPU
      AutoRemove: true
    },
    Env: Object.entries(envVars).map(([k, v]) => `${k}=${v}`),
    Tty: false,
    AttachStdout: true,
    AttachStderr: true
  });

  const stream = await container.attach({
    stream: true,
    stdout: true,
    stderr: true
  });

  // Collect logs
  stream.on('data', (chunk: Buffer) => {
    const header = chunk.slice(0, 8);
    const payload = chunk.slice(8);
    const isStderr = header[0] === 2; // Docker stream multiplexing
    
    logs.push({
      timestamp: new Date().toISOString(),
      stream: isStderr ? 'stderr' : 'stdout',
      message: payload.toString('utf-8').trim()
    });
  });

  await container.start();

  // Timeout handling
  const timeout = setTimeout(async () => {
    logger.warn(`Container timeout: ${container.id}`);
    await container.stop();
  }, timeoutMs);

  const result = await container.wait();
  clearTimeout(timeout);

  const duration = Date.now() - startTime;
  
  return {
    exitCode: result.StatusCode || 0,
    logs,
    duration
  };
}

export async function buildRunnerImage(): Promise<void> {
  try {
    const stream = await docker.buildImage({
      context: './packages/runner',
      src: ['Dockerfile', 'scripts']
    }, { t: 'ai-coding-runner:latest' });
    
    return new Promise((resolve, reject) => {
      docker.modem.followProgress(stream, (err) => {
        if (err) reject(err);
        else resolve();
      });
    });
  } catch (error) {
    logger.error('Failed to build runner image:', error);
    throw error;
  }
}