import Database from 'better-sqlite3';
import { join } from 'path';
import { existsSync, mkdirSync } from 'fs';

const DB_DIR = join(process.cwd(), 'data');
const DB_PATH = process.env.DB_PATH || join(DB_DIR, 'ai-coding.db');

// Ensure data directory exists
if (!existsSync(DB_DIR)) {
  mkdirSync(DB_DIR, { recursive: true });
}

export const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

// Initialize tables
export function initDatabase() {
  // Users & RBAC
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT DEFAULT 'viewer' CHECK(role IN ('admin', 'dev', 'viewer')),
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS projects (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      description TEXT,
      source_type TEXT CHECK(source_type IN ('github', 'zip', 'local')),
      source_url TEXT,
      local_path TEXT NOT NULL,
      stack_detected TEXT,
      stack_confidence REAL,
      install_command TEXT,
      run_command TEXT,
      build_command TEXT,
      env_keys_required TEXT, -- JSON array
      status TEXT DEFAULT 'imported' CHECK(status IN ('imported', 'analyzing', 'ready', 'error', 'running')),
      created_by TEXT REFERENCES users(id),
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS project_files (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      project_id TEXT REFERENCES projects(id) ON DELETE CASCADE,
      path TEXT NOT NULL,
      content_hash TEXT,
      size_bytes INTEGER,
      is_binary BOOLEAN DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS executions (
      id TEXT PRIMARY KEY,
      project_id TEXT REFERENCES projects(id) ON DELETE CASCADE,
      type TEXT CHECK(type IN ('install', 'run', 'build', 'test', 'lint', 'ai_fix')),
      command TEXT NOT NULL,
      status TEXT DEFAULT 'pending' CHECK(status IN ('pending', 'running', 'success', 'failed', 'cancelled')),
      exit_code INTEGER,
      logs TEXT, -- JSON array of log lines
      started_at DATETIME,
      completed_at DATETIME,
      created_by TEXT REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS ai_plans (
      id TEXT PRIMARY KEY,
      project_id TEXT REFERENCES projects(id) ON DELETE CASCADE,
      user_prompt TEXT NOT NULL,
      plan_text TEXT NOT NULL,
      affected_files TEXT, -- JSON array
      diff_patch TEXT,
      status TEXT DEFAULT 'draft' CHECK(status IN ('draft', 'approved', 'rejected', 'applied', 'failed')),
      created_by TEXT REFERENCES users(id),
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      applied_at DATETIME
    );

    CREATE TABLE IF NOT EXISTS audit_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT REFERENCES users(id),
      action TEXT NOT NULL,
      entity_type TEXT NOT NULL,
      entity_id TEXT NOT NULL,
      severity TEXT CHECK(severity IN ('info', 'warning', 'critical')),
      ip_address TEXT,
      user_agent TEXT,
      details TEXT, -- JSON
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS secrets (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      project_id TEXT REFERENCES projects(id) ON DELETE CASCADE,
      key_name TEXT NOT NULL,
      encrypted_value TEXT NOT NULL,
      created_by TEXT REFERENCES users(id),
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      UNIQUE(project_id, key_name)
    );

    CREATE INDEX IF NOT EXISTS idx_projects_status ON projects(status);
    CREATE INDEX IF NOT EXISTS idx_executions_project ON executions(project_id);
    CREATE INDEX IF NOT EXISTS idx_audit_logs_user ON audit_logs(user_id);
    CREATE INDEX IF NOT EXISTS idx_audit_logs_created ON audit_logs(created_at);
  `);

  // Create default admin user (password: admin123)
  const adminExists = db.prepare('SELECT id FROM users WHERE email = ?').get('admin@system.local');
  if (!adminExists) {
    const bcrypt = await import('bcryptjs');
    const hash = await bcrypt.hash('admin123', 10);
    db.prepare(`
      INSERT INTO users (id, email, password_hash, role) 
      VALUES (?, ?, ?, ?)
    `).run(crypto.randomUUID(), 'admin@system.local', hash, 'admin');
  }

  console.log('✅ Database initialized');
}

export default db;