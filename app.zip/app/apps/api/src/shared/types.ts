export interface User {
  id: string;
  email: string;
  role: 'admin' | 'dev' | 'viewer';
}

export interface Project {
  id: string;
  name: string;
  description?: string;
  source_type: 'github' | 'zip' | 'local';
  source_url?: string;
  local_path: string;
  stack_detected?: string;
  stack_confidence?: number;
  install_command?: string;
  run_command?: string;
  build_command?: string;
  env_keys_required?: string[];
  status: 'imported' | 'analyzing' | 'ready' | 'error' | 'running';
  created_by: string;
  created_at: string;
}

export interface StackInfo {
  name: string;
  confidence: number;
  installCmd: string;
  runCmd: string;
  buildCmd?: string;
  envKeys: string[];
  files: string[];
}

export interface Execution {
  id: string;
  project_id: string;
  type: 'install' | 'run' | 'build' | 'test' | 'lint' | 'ai_fix';
  command: string;
  status: 'pending' | 'running' | 'success' | 'failed' | 'cancelled';
  exit_code?: number;
  logs: LogEntry[];
  started_at?: string;
  completed_at?: string;
}

export interface LogEntry {
  timestamp: string;
  stream: 'stdout' | 'stderr';
  message: string;
}

export interface AIPlan {
  id: string;
  project_id: string;
  user_prompt: string;
  plan_text: string;
  affected_files: string[];
  diff_patch?: string;
  status: 'draft' | 'approved' | 'rejected' | 'applied' | 'failed';
}