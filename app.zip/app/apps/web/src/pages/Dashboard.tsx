import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { 
  Folder, 
  Play, 
  CheckCircle, 
  AlertCircle,
  Clock,
  Plus
} from 'lucide-react';
import api from '../services/api';

interface Project {
  id: string;
  name: string;
  stack_detected: string;
  status: string;
  created_at: string;
}

export default function Dashboard() {
  const { data: projects, isLoading } = useQuery({
    queryKey: ['projects'],
    queryFn: () => api.get('/projects').then(r => r.data as Project[]),
  });

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'ready': return <CheckCircle size={16} className="text-green-500" />;
      case 'running': return <Play size={16} className="text-blue-500" />;
      case 'error': return <AlertCircle size={16} className="text-red-500" />;
      default: return <Clock size={16} className="text-yellow-500" />;
    }
  };

  if (isLoading) {
    return <div className="p-6">Loading projects...</div>;
  }

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Projects</h1>
        <Link to="/import" className="btn-primary flex items-center gap-2">
          <Plus size={18} />
          New Project
        </Link>
      </div>

      {projects?.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-lg shadow">
          <Folder size={48} className="mx-auto text-gray-400 mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No projects yet</h3>
          <p className="text-gray-600 mb-4">Import your first project to get started</p>
          <Link to="/import" className="btn-primary inline-flex items-center gap-2">
            <Plus size={18} />
            Import Project
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {projects?.map((project) => (
            <Link
              key={project.id}
              to={`/project/${project.id}`}
              className="card hover:shadow-lg transition-shadow group"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="bg-primary-100 p-2 rounded group-hover:bg-primary-200 transition-colors">
                  <Folder size={24} className="text-primary-600" />
                </div>
                {getStatusIcon(project.status)}
              </div>
              
              <h3 className="font-semibold text-lg mb-1">{project.name}</h3>
              <p className="text-sm text-gray-600 mb-2">{project.stack_detected}</p>
              
              <div className="flex items-center justify-between text-xs text-gray-500">
                <span className="capitalize">{project.status}</span>
                <span>{new Date(project.created_at).toLocaleDateString()}</span>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}