import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Github, Upload, Loader2 } from 'lucide-react';
import api from '../services/api';

export default function ImportProject() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'github' | 'zip'>('github');
  const [githubUrl, setGithubUrl] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleGithubImport = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    
    try {
      const { data } = await api.post('/projects/import/github', { url: githubUrl });
      navigate(`/project/${data.projectId}`);
    } catch (err: any) {
      setError(err.response?.data?.error || 'Import failed');
    } finally {
      setLoading(false);
    }
  };

  const handleZipImport = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file) return;
    
    setLoading(true);
    setError('');
    
    const formData = new FormData();
    formData.append('file', file);
    
    try {
      const { data } = await api.post('/projects/import/zip', formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      navigate(`/project/${data.projectId}`);
    } catch (err: any) {
      setError(err.response?.data?.error || 'Import failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto p-6">
      <h1 className="text-2xl font-bold mb-6">Import Project</h1>
      
      <div className="flex gap-4 mb-6 border-b">
        <button
          onClick={() => setActiveTab('github')}
          className={`pb-2 px-4 flex items-center gap-2 ${activeTab === 'github' ? 'border-b-2 border-primary-600 text-primary-600' : 'text-gray-500'}`}
        >
          <Github size={20} />
          GitHub
        </button>
        <button
          onClick={() => setActiveTab('zip')}
          className={`pb-2 px-4 flex items-center gap-2 ${activeTab === 'zip' ? 'border-b-2 border-primary-600 text-primary-600' : 'text-gray-500'}`}
        >
          <Upload size={20} />
          Upload ZIP
        </button>
      </div>

      {error && (
        <div className="bg-red-50 text-red-600 p-3 rounded mb-4">
          {error}
        </div>
      )}

      {activeTab === 'github' ? (
        <form onSubmit={handleGithubImport} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1">GitHub URL</label>
            <input
              type="url"
              value={githubUrl}
              onChange={(e) => setGithubUrl(e.target.value)}
              placeholder="https://github.com/user/repo"
              className="w-full p-2 border rounded focus:ring-2 focus:ring-primary-500"
              required
            />
          </div>
          <button
            type="submit"
            disabled={loading}
            className="w-full bg-primary-600 text-white py-2 rounded hover:bg-primary-700 disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {loading && <Loader2 className="animate-spin" size={20} />}
            Import from GitHub
          </button>
        </form>
      ) : (
        <form onSubmit={handleZipImport} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1">ZIP File</label>
            <input
              type="file"
              accept=".zip"
              onChange={(e) => setFile(e.target.files?.[0] || null)}
              className="w-full p-2 border rounded"
              required
            />
            <p className="text-sm text-gray-500 mt-1">Max size: 50MB</p>
          </div>
          <button
            type="submit"
            disabled={loading || !file}
            className="w-full bg-primary-600 text-white py-2 rounded hover:bg-primary-700 disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {loading && <Loader2 className="animate-spin" size={20} />}
            Upload & Import
          </button>
        </form>
      )}
    </div>
  );
}