import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Play, Terminal, FileTree, Bot, Loader2 } from 'lucide-react';
import api from '../services/api';

interface Project {
  id: string;
  name: string;
  stack_detected: string;
  install_command: string;
  run_command: string;
  status: string;
}

interface Execution {
  id: string;
  status: string;
  logs: Array<{ stream: string; message: string; timestamp: string }>;
}

export default function ProjectView() {
  const { id } = useParams<{ id: string }>();
  const [activeTab, setActiveTab] = useState<'overview' | 'run' | 'ai'>('overview');
  const [command, setCommand] = useState('');
  const [logs, setLogs] = useState<string[]>([]);

  const { data: project } = useQuery({
    queryKey: ['project', id],
    queryFn: () => api.get(`/projects/${id}`).then(r => r.data as Project),
  });

  const runMutation = useMutation({
    mutationFn: (cmd: string) => api.post(`/projects/${id}/run`, { command: cmd }),
    onSuccess: (data) => {
      pollExecution(data.data.executionId);
    },
  });

  const aiAnalyzeMutation = useMutation({
    mutationFn: () => api.post(`/ai/${id}/analyze`),
  });

  const pollExecution = async (executionId: string) => {
    const interval = setInterval(async () => {
      const { data } = await api.get(`/projects/${id}/executions/${executionId}`);
      const exec = data as Execution;
      
      setLogs(exec.logs.map(l => `[${l.stream}] ${l.message}`));
      
      if (exec.status !== 'pending' && exec.status !== 'running') {
        clearInterval(interval);
      }
    }, 1000);
  };

  if (!project) return <div className="p-6">Loading...</div>;

  return (
    <div className="p-6">
      <div className="flex justify-between items-start mb-6">
        <div>
          <h1 className="text-2xl font-bold">{project.name}</h1>
          <p className="text-gray-600">
            Stack: {project.stack_detected} | Status: 
            <span className={`ml-1 px-2 py-0.5 rounded text-sm ${
              project.status === 'ready' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
            }`}>
              {project.status}
            </span>
          </p>
        </div>
      </div>

      <div className="flex gap-4 mb-6 border-b">
        {[
          { id: 'overview', label: 'Overview', icon: FileTree },
          { id: 'run', label: 'Run & Debug', icon: Play },
          { id: 'ai', label: 'AI Agent', icon: Bot },
        ].map(({ id: tab, label, icon: Icon }) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab as any)}
            className={`pb-2 px-4 flex items-center gap-2 ${activeTab === tab ? 'border-b-2 border-primary-600 text-primary-600' : 'text-gray-500'}`}
          >
            <Icon size={18} />
            {label}
          </button>
        ))}
      </div>

      {activeTab === 'run' && (
        <div className="space-y-4">
          <div className="flex gap-2">
            <button
              onClick={() => runMutation.mutate(project.install_command)}
              disabled={runMutation.isPending}
              className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 disabled:opacity-50"
            >
              {runMutation.isPending ? <Loader2 className="animate-spin inline" size={18} /> : 'Install'}
            </button>
            <button
              onClick={() => runMutation.mutate(project.run_command)}
              disabled={runMutation.isPending}
              className="bg-primary-600 text-white px-4 py-2 rounded hover:bg-primary-700 disabled:opacity-50"
            >
              {runMutation.isPending ? <Loader2 className="animate-spin inline" size={18} /> : 'Run'}
            </button>
          </div>

          <div className="border rounded bg-black text-green-400 p-4 font-mono text-sm h-96 overflow-auto">
            <div className="flex items-center gap-2 mb-2 text-gray-400 border-b border-gray-700 pb-2">
              <Terminal size={16} />
              Terminal
            </div>
            {logs.length === 0 ? (
              <p className="text-gray-500">Click Install or Run to see logs...</p>
            ) : (
              logs.map((log, i) => (
                <div key={i} className="whitespace-pre-wrap">{log}</div>
              ))
            )}
          </div>
        </div>
      )}

      {activeTab === 'ai' && (
        <div className="space-y-4">
          <button
            onClick={() => aiAnalyzeMutation.mutate()}
            disabled={aiAnalyzeMutation.isPending}
            className="bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700 disabled:opacity-50"
          >
            {aiAnalyzeMutation.isPending ? <Loader2 className="animate-spin inline" size={18} /> : 'Analyze Project'}
          </button>
          
          {aiAnalyzeMutation.data && (
            <div className="bg-gray-50 p-4 rounded border">
              <h3 className="font-semibold mb-2">Analysis Results</h3>
              <pre className="whitespace-pre-wrap text-sm">{aiAnalyzeMutation.data.data.analysis}</pre>
            </div>
          )}
        </div>
      )}
    </div>
  );
}