# AI Coding System 🤖

نظام برمجة متكامل يتيح استيراد المشاريع، تشغيلها في بيئة معزولة، واستخدام AI لتحليل وتحسين الكود.

## المميزات الرئيسية

- ✅ استيراد من GitHub أو ZIP
- ✅ كشف التقنيات تلقائياً (Node, Python, Java, .NET)
- ✅ تشغيل آمن في Docker Sandbox
- ✅ AI Agent لتحليل المشاريع واقتراح التحسينات
- ✅ Admin Panel مع Audit Logs و RBAC
- ✅ واجهة عربية/إنجليزية

## التشغيل السريع

### 1. المتطلبات
- Docker & Docker Compose
- Node.js 20+ (للتطوير المحلي)

### 2. الإعداد
```bash
# Clone
git clone &lt;repo&gt;
cd ai-coding-system

# Environment
cp apps/api/.env.example apps/api/.env
# عدل OPENAI_API_KEY و JWT_SECRET

# Run
docker-compose up --build